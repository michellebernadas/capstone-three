<?php $__env->startSection('title', 'Threads'); ?>
	

<?php $__env->startSection('content'); ?>

	<div class="container thread mt-5">

<div class="margin">

	<ol class="breadcrumb mt-5">
	  <li class="breadcrumb-item"><a href="/home">Home</a></li>
	  <li class="breadcrumb-item"><a href="/forum">Forum</a></li>
	<?php if(isset($thread)): ?>
	  <li class="breadcrumb-item"><a href="/forum/<?php echo e($thread->topic->name); ?>/<?php echo e($thread->topic->id); ?>"><?php echo e($thread->topic->name); ?></a></li>
	</ol>
</div>
		<h2 id="topic_subject" "><?php echo e($thread->subject); ?></h2>
		<hr>
		
		<div class="flag_message"></div>

		<ul class="list-unstyled thread mb-5" id="<?php echo e($thread->id); ?>">
		  <li class="media">
		  	
		    <img class="mr-3 thread_image" src="/<?php echo e($thread->user->image); ?>" alt="User Image" onerror="this.onerror=null;this.src='<?php echo e(URL::asset('images/placeholder.jpg')); ?>'">
		    <div class="media-body col-9 mt-3">
		      <h5 class="mt-0 mb-4"><?php echo e($thread->user->username); ?></h5>
		      <div class="content mb-4" id="content">
		      		<?php echo $thread->content; ?>	
		      </div>
		    </div>
		    <div class="media-body col-3 mt-3 text-right">
		    	
		    	<p class="thread_time"><?php echo e($thread->updated_at->diffForHumans()); ?></p>
		    </div>
		  </li>
		  <hr>

		  <div class="row">
		    <?php if(Auth::user()): ?>

		    <?php if(!Auth::user()->likes->contains($thread)): ?>
		    	<a href="/<?php echo e($thread->id); ?>/like"><i class="col-md-6 far fa-heart" id="like" data-id="<?php echo e($thread->id); ?>"></i></a>
			<?php else: ?>
				<a href="/<?php echo e($thread->id); ?>/unlike"><i class="col-md-6 far fa-heart" id="unlike" data-id="<?php echo e($thread->id); ?>"></i></a>
			<?php endif; ?>


			<?php if(count($thread->likes)>0): ?>
				<span class="float-left"> <?php echo e(count($thread->likes)); ?></span>
			<?php endif; ?>
			

		    <div class="col-md-6 text-right pr-4">
		    	
		    	
		    		<i id="edit_image" data-id="<?php echo e($thread->id); ?>" class="fas fa-edit mr-2"></i>
		    		<i class="fas fa-trash mr-2"  data-toggle="modal" data-target="#delete"></i>
		    	

		    	<i id="thread_flag" class="fas fa-flag" data-id="<?php echo e($thread->id); ?>" data-toggle="modal" data-target="#report"></i>
		    </div>
		    <?php endif; ?>
		  </div>
		</ul>

		
		<div class="modal fade" id="edit">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Edit Thread</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        <?php echo $__env->make('partials.edit_thread', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-primary" id="update_thread" data-id="<?php echo e($thread->id); ?>">Update</button>
		      </div>

		    </div>
		  </div>
		</div>


		
		<div class="modal fade" id="delete">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Delete Thread</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        Are you sure you want to delete your Thread?
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" id="thread_delete" class="btn btn-danger" data-id="<?php echo e($thread->id); ?>">Delete</button>
		      </div>

		    </div>
		  </div>
		</div>

		
		<div class="modal fade" id="report">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Report Thread</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		      	<div class="row">
		        	<textarea id="report_thread" class="form-control mx-4" rows="7" placeholder="Report Content"></textarea>
		        </div>
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-primary" id="report_thread" data-id="<?php echo e($thread->id); ?>">Report</button>
		      </div>

		    </div>
		  </div>
		</div>

	<div class="comment_report"></div>


	<div class="comment-container">
		<?php $__currentLoopData = $thread->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		

			<ul class="list-unstyled replies" id="<?php echo e($comment->id); ?>">

				<li class="media">
				    <img class="mr-3 thread_image" src="/<?php echo e($comment->user->image); ?>" alt="User Image" onerror="this.onerror=null;this.src='<?php echo e(URL::asset('images/placeholder.jpg')); ?>'">
				    <div class="media-body col-9 mt-3">
				      <h5 class="mt-0 mb-4"><?php echo e($comment->user->username); ?></h5>
				      <div class="comment_content mb-4" id="comment<?php echo e($comment->id); ?>">
				      		<?php echo $comment->content; ?>	
				      </div>
				    </div>
				    <div class="media-body col-3 mt-3 text-right">
				    	
				    	<p class="comment_time" id="time<?php echo e($comment->id); ?>"><?php echo e($comment->updated_at->diffForHumans()); ?></p>
				    </div>
				 </li>
				 <hr>

				  <div class="row">
				    
				    <?php if(Auth::user()): ?>
				    
				    <div class="col-md-12 text-right pr-4 mb-5">
				    	
				    	
				    		<i data-id="<?php echo e($comment->id); ?>" class="fas fa-edit mr-2 comment_edit_image"></i>
				    		<i class="fas fa-trash mr-2 trash" data-id="<?php echo e($comment->id); ?>"></i>
				    	
				    		<i class="fas fa-flag" data-id="<?php echo e($comment->id); ?>" id="flag<?php echo e($comment->id); ?>" data-toggle="modal" data-target="#report_comment"></i>
				    </div>
				    <?php endif; ?>
				  </div>
			</ul>
		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div> 
		
			
			


		<?php if(Auth::user()): ?>
		<div class="reply_container">
			<textarea id="thread_content" class="contents"></textarea>
			<button class="btn btn-info" id="reply_thread" data-index="<?php echo e($thread->id); ?>">POST REPLY</button>
		</div>
		<?php else: ?>
		<div class="alert alert-primary" role="alert">
			You Must Sign In or Register To Reply A Thread
		</div>
		<?php endif; ?>
    </div>



    	
		<div class="modal fade" id="comment_edit">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Edit Comment</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
				<div class="container mt-2">
						<textarea id="commented_thread" class="contents form-control">
							
						</textarea>
				</div>

		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		      	
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-primary comment_update" data-id="">Update</button>
		        
		      </div>

		    </div>
		</div>
	</div>

	
		<div class="modal fade" id="comment_delete">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header delete">
		        <h4 class="modal-title">Delete Comment</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        Are you sure you want to delete your Comment?
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-danger comment_delete">Delete</button>
		      </div>

		    </div>
		  </div>
		</div>

		
		<div class="modal fade" id="report_comment">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header comment_flag">
		        <h4 class="modal-title">Report Comment</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        <div class="row">
		        	<textarea class="form-control mx-4" rows="7" id="commentflag_content" placeholder="Report Content"></textarea>
		        </div>
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-danger comment_flag" data-id="<?php echo e($thread->id); ?>">Report</button>
		      </div>

		    </div>
		  </div>
		</div>
	

    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>