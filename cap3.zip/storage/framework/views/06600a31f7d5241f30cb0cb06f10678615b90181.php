<footer class="page-footer font-small unique-color-dark pt-4">

    <div class="container-fluid footer">

       <div class="row text-center d-flex justify-content-center pt-5 mb-3">
        
        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="#!">About us</a>
          </h6>
        </div>

        <div class="col-md-2 mb-3">
          <h6 class="text-uppercase font-weight-bold">
            <a href="#!">Products</a>
          </h6>
        </div>

      </div>

      <div class="col-md-12">
        <div class="flex-center text-center pb-3">
          <ul class="social-network social-circle">
              <li><a href="https://rss.com/" class="icoRss" title="Rss"><i class="fa fa-rss"></i></a></li>
              <li><a href="https://www.facebook.com/" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="https://twitter.com/?lang=en" class="icoTwitter" title="Twitter"><i class="fa fa-twitter"></i></a></li>
              <li><a href="https://plus.google.com/" class="icoGoogle" title="Google +"><i class="fa fa-google-plus"></i></a></li>
              <li><a href="https://www.linkedin.com/" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
          </ul>       
        </div>
      </div>
    
    </div>

    <div class="footer-copyright text-center py-3">© 2018 Copyright Christian Forum
       

    </div>

</footer>