<?php $__env->startSection('title', 'Post Thread'); ?>
	<div class="forum_image">
        <h1>FORUMS</h1>
    </div>

<?php $__env->startSection('content'); ?>

		<div class="row mt-5">
			<h2>Post Thread</h2>
		</div>
	<div class="post_container mt-2">

		<form class="mx-auto">
		  <div class="form-group">
		    <input type="text" class="form-control" id="thread_title" placeholder="Thread Title">
		  </div>
				
			<textarea id="thread_content" class="contents">
			</textarea>

			<button type="button" class="btn btn-primary" id="post_btn">Post Thread</button>
		</form>
	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>