<?php $__env->startSection('title', 'Thread'); ?>
	<div class="forum_image">
        <h1>FORUMS</h1>
    </div>

<?php $__env->startSection('content'); ?>

	<a href="/forum/<?php echo e($name); ?>/<?php echo e($id); ?>/post_thread" class="btn btn-info mt-5">Post Thread</a>

	<div class="mt-5">
		<table class="table table-hover table-striped">
		  <thead class="thead-dark">
		    <tr>
		      <th scope="col">Topic</th>
		      <th scope="col">Users</th>
		      <th scope="col">Replies</th>
		      <th scope="col">Views</th>
		      <th scope="col">Activity</th>
		    </tr>
		  </thead>
		  <tbody>
		    <tr>
		      <th scope="row">1</th>
		      <td>Mark</td>
		      <td>Otto</td>
		      <td>@mdo</td>
		    </tr>
		    <tr>
		      <th scope="row">2</th>
		      <td>Jacob</td>
		      <td>Thornton</td>
		      <td>@fat</td>
		    </tr>
		    <tr>
		      <th scope="row">1</th>
		      <td>Mark</td>
		      <td>Otto</td>
		      <td>@mdo</td>
		    </tr>
		  </tbody>
		</table>
				
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>