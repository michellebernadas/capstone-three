<?php $__env->startSection('title', 'Threads'); ?>
	<div class="forum_image">
        <h1>THREADS</h1>
    </div>

<?php $__env->startSection('content'); ?>


	<div class="container mt-5">


	<ol class="breadcrumb mt-5">
	  <li class="breadcrumb-item"><a href="/home">Home</a></li>
	  <li class="breadcrumb-item"><a href="/forum">Forum</a></li>
	  <li class="breadcrumb-item"><a href="/forum/<?php echo e($thread->topic->name); ?>/<?php echo e($thread->topic->id); ?>"><?php echo e($thread->topic->name); ?></a></li>
	  <li class="breadcrumb-item"><a href="/threads/<?php echo e($thread->topic->name); ?>/<?php echo e($thread->topic->id); ?>/<?php echo e($thread->subject); ?>/<?php echo e($thread->id); ?>'"><?php echo e($thread->subject); ?></a></li>
	</ol>


		<h2 id="topic_subject" "><?php echo e($thread->subject); ?></h2>
		<hr>

		<ul class="list-unstyled thread" id="<?php echo e($thread->id); ?>">
		  <li class="media">
		    <img class="mr-3 thread_image" src="/<?php echo e($thread->user->image); ?>" alt="User Image">
		    <div class="media-body col-9 mt-3">
		      <h5 class="mt-0 mb-4"><?php echo e($thread->user->username); ?></h5>
		      <div class="content mb-4" id="content">
		      		<?php echo $thread->content; ?>	
		      </div>
		    </div>
		    <div class="media-body col-3 mt-3 text-right">
		    	
		    	<p class="time"><?php echo e($thread->created_at->diffForHumans()); ?></p>
		    </div>
		  </li>
		  <hr>

		  <div class="row">
		    <?php if(Auth::user()): ?>
		    <i class="col-md-6 far fa-heart"></i>
		    <div class="col-md-6 text-right pr-4">
		    	<i id="comment_image" data-id="<?php echo e($thread->id); ?>" class="fas fa-comment-dots mr-2"></i>
		    	
		    		<i id="edit_image" data-id="<?php echo e($thread->id); ?>" class="fas fa-edit mr-2"></i>
		    		<i class="fas fa-trash"  data-toggle="modal" data-target="#delete"></i>
		    	
		    	<i class="fas fa-flag"></i>
		    </div>
		    <?php endif; ?>
		  </div>
		</ul>

		
		<div class="modal fade" id="edit">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Edit Thread</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        <?php echo $__env->make('partials.edit_thread', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-primary" id="update_thread" data-id="<?php echo e($thread->id); ?>">Update</button>
		      </div>

		    </div>
		  </div>
		</div>


		
		<div class="modal fade" id="delete">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Delete Post</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        Are you sure you want to delete your post?
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" id="thread_delete" class="btn btn-danger" data-id="<?php echo e($thread->id); ?>">Delete</button>
		      </div>

		    </div>
		  </div>
		</div>

		

		<?php $__currentLoopData = $thread->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($thread->id == $comment->thread_id): ?>

			<ul class="list-unstyled replies" id="<?php echo e($comment->id); ?>">

				<li class="media">
				    <img class="mr-3 thread_image" src="/<?php echo e($comment->user->image); ?>" alt="User Image">
				    <div class="media-body col-9 mt-3">
				      <h5 class="mt-0 mb-4"><?php echo e($comment->user->username); ?></h5>
				      <div class="content mb-4" id="content">
				      		<?php echo $comment->content; ?>	
				      </div>
				    </div>
				    <div class="media-body col-3 mt-3 text-right">
				    	
				    	<p class="time"><?php echo e($comment->created_at->diffForHumans()); ?></p>
				    </div>
				 </li>
				 <hr>

				  <div class="row">
				    
				    <?php if(Auth::user()): ?>
				    <i class="col-md-6 far fa-heart"></i>
				    <div class="col-md-6 text-right pr-4">
				    	<i id="comment_image" data-id="<?php echo e($comment->id); ?>" class="fas fa-comment-dots mr-2"></i>
				    	
				    		<i id="comment_edit_image" data-id="<?php echo e($comment->id); ?>" class="fas fa-edit mr-2"></i>
				    		<i id="comment_delete" class="fas fa-trash" data-id="<?php echo e($comment->id); ?>"></i>
				    	
				    	<i class="fas fa-flag"></i>
				    </div>
				    <?php endif; ?>
				  </div>
			</ul>
		<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		
		<div class="modal fade" id="comment_edit">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Edit Comment</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body" id="comment_body">
		        <textarea id="commented_thread" class="contents form-control">
				
				</textarea>
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-primary">Update</button>
		      </div>

		    </div>
		  </div>
		</div>
		
			<ul class="list-unstyled new_replies"></ul>

		<?php if(Auth::user()): ?>
		<div class="reply_container">
			<textarea id="thread_content" class="contents" name="reply_content"></textarea>
			<button class="btn btn-info" id="repy_thread" data-index="<?php echo e($thread->id); ?>">POST REPLY</button>
		</div>
		<?php endif; ?>

		<div class="alert alert-primary" role="alert">
			You Must Sign In or Register To Reply A Thread
		</div>
	

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>