<div class="post_container mt-2">

		
			<?php echo e(csrf_field()); ?>

			<?php echo e(method_field('PATCH')); ?>

		  <div class="form-group">
		    <input type="text" class="form-control" id="edit_subject" name="subject" value="<?php echo e($thread->subject); ?>">

		  </div>
			<textarea id="thread" class="contents form-control" name="thread_content" value="<?php echo e($thread->content); ?>">
				<?php echo $thread->content; ?>

			</textarea>

		

	</div>