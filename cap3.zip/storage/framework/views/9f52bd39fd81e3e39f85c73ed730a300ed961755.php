<?php $__env->startSection('title', 'Profile'); ?>
	
<?php $__env->startSection('content'); ?>
	
	<div class="margin-container">	
		<div class="card profile mt-5">
			<div class="row pt-5">
				<div class="col-4 ml-5">
					<div class="prof_holder">

	            		<img class="prof_image" src="<?php echo e(Auth::user()->image); ?>" data-toggle="modal" data-target="#image" onerror="this.onerror=null;this.src='<?php echo e(URL::asset('images/placeholder.jpg')); ?>'">	
					</div>

					<div class="row">
		                <div class="col-6 offset-2 mt-3 mb-5">
		                    <h2 id="prof_username"><?php echo e(Auth::user()->username); ?></h2>
		                </div>
		        	</div>
				</div> 

				<div class="col-7">

					<ul class="nav nav-tabs" role="tablist">
					  <li class="nav-item">
						<a class="nav-link active" data-toggle="tab" href="#about" role="tab">About</a>
					  </li>
					  <li class="nav-item">
						<a class="nav-link" data-toggle="tab" href="#edit" role="tab">Edit</a>
					  </li>
					</ul>

					<div class="tab-content">
						<div class="tab-pane active" id="about" role="tabpanel">
							<div class="row mt-4">
									<p>Full Name: </p>
									<span id="first_name" class="pl-2"> <?php echo e(Auth::user()->first_name); ?></span>
									<span id="last_name" class="pl-1"> <?php echo e(Auth::user()->last_name); ?></span>
							</div>
							<div class="row">
									<p>Email: </p>
									<span id="email" class="pl-2"><?php echo e(Auth::user()->email); ?></span>
							</div>
							<div class="row">
									<p>Joined: </p>
									<span class="pl-2"><?php echo e(Auth::user()->created_at); ?></span>
							</div>

						</div> 

						<div class="tab-pane fade" id="edit" role="tabpanel"><div class="success_message"></div>			
		                    <form role="form">
		                    	<?php echo e(csrf_field()); ?>

		                        <div class="form-group row mt-3">
		                            <label class="col-lg-3 col-form-label form-control-label">First name</label>
		                            <div class="col-lg-9">
		                                <input class="form-control" type="text" id="first_name" value="<?php echo e(Auth::user()->first_name); ?>">
		                            </div>
		                        </div>
		                        <div class="form-group row">
		                            <label class="col-lg-3 col-form-label form-control-label">Last name</label>
		                            <div class="col-lg-9">
		                                <input class="form-control" type="text" id="last_name" value="<?php echo e(Auth::user()->last_name); ?>">
		                            </div>
		                        </div>
		                        <div class="form-group row">
		                            <label class="col-lg-3 col-form-label form-control-label">Email</label>
		                            <div class="col-lg-9">
		                                <input class="form-control" type="email" id="email" value="<?php echo e(Auth::user()->email); ?>">
		                            </div>
		                        </div>

		                        <div class="form-group row">
		                            <label class="col-lg-3 col-form-label form-control-label">Username</label>
		                            <div class="col-lg-9">
		                                <input class="form-control" type="text" id="username" value="<?php echo e(Auth::user()->username); ?>">
		                            </div>
		                        </div>

		                        <div class="form-group row">
		                            <div class="offset-4 mt-4">
		                                <button type="button" class="btn btn-primary" id="update" data-id="<?php echo e(Auth::user()->id); ?>">Save Changes</button>
		                            </div>
		                        </div>
		                    </form>

						</div> 
							
					</div> 



				</div> 

				
			</div> 
			
		</div> 
	</div>

	
	<div class="modal fade" id="image">
			  <div class="modal-dialog">
			    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Change Picture</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		      	<form method="POST" enctype="multipart/form-data" action="/user/<?php echo e(Auth::user()->id); ?>">
		      		<?php echo e(csrf_field()); ?>

		      		<?php echo e(method_field('PATCH')); ?>

			        <div class="form-group-row image-holder mx-auto">
			        	<div class="center_image">
				        	<?php if("<?php echo e(Auth::user()->image); ?>"): ?>
        						<img class="user_img" src="<?php echo e(Auth::user()->image); ?>">
        					<?php endif; ?>
    					</div>
			        </div>
				        <div class="form-group-row mt-4">
	                            <label for="image" class="col-md-4 col-form-label text-md-right"></label>
	                            <input id="image" type="file" name="image" >
	                    </div>
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button class="btn btn-success">Change</button>
		      </div>

	        	</form>
	    </div>
	  </div>
	</div>



	
		<ul class="nav nav-tabs" role="tablist">
		  <li class="nav-item">
			<a class="nav-link active" data-toggle="tab" href="#activity" role="tab">Latest Activity</a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#alerts" role="tab">Alerts</a>
		  </li>
		  <li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#postings" role="tab">Postings</a>
		  </li>
		  <?php if(Auth::user()->role_id==1): ?>
		  <li class="nav-item">
			<a class="nav-link" data-toggle="tab" href="#reports" role="tab">Reports</a>
		  </li>	
		  <?php endif; ?>					 							  
		</ul>

	<!-- Tab panes -->
		<div class="tab-content">
		  <div class="tab-pane active" id="activity" role="tabpanel"> 	
			<table class="table table-hover table-striped">
                <tbody class="activity">
      
                	<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php if($thread->id == $comment->thread_id): ?>
                	
                    <tr>
                        <td class="activity">
                        	<div class="row">
                        	<div class="col-1">
							<img class="prof_img" src="/<?php echo e(Auth::user()->image); ?>" onerror="this.onerror=null;this.src='<?php echo e(URL::asset('images/placeholder.jpg')); ?>'">
							</div>
							<div class="col-10">
                            <strong><?php echo e(Auth::user()->username); ?></strong><span> commented </span> on <strong><?php echo e($thread->subject); ?></strong>
                            <span><?php echo $comment->content; ?></span>
                            <p><?php echo e($comment->created_at->format('F j, Y g:i:s a')); ?></p>
                            </div>
							</div>
                        </td>
                    </tr>
                    
                    <?php endif; ?>
            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            
            </table>	

		 </div> 

		  <div class="tab-pane" id="alerts" role="tabpanel"> 

            <table class="table table-hover table-striped">
                <tbody class="activity">
      
                	<?php $__currentLoopData = $thread_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php $__currentLoopData = $all_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($comment->thread_id == $thread->id): ?>
                	
                    <tr>
						<td class="activity">
                        	<div class="row">
                        	<div class="col-1">
							<img class="prof_img" src="/<?php echo e($comment->user->image); ?>" onerror="this.onerror=null;this.src='<?php echo e(URL::asset('images/placeholder.jpg')); ?>'">
							</div>
							<div class="col-10">
                            <strong><?php echo e($comment->user->username); ?></strong><span> replied to your thread  </span> <strong><?php echo e($thread->subject); ?></strong>
                            <span><?php echo $comment->content; ?></span>
                            <p><?php echo e($comment->created_at->format('F j, Y g:i:s a')); ?></p>
                            </div>
							</div>
                        </td>
                    </tr>
                    
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>	
		  </div> 
		 
		  <div class="tab-pane" id="postings" role="tabpanel"> 

		  	 <table class="table table-hover table-striped">
                <tbody class="activity">
      
                	<?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  			<?php if($thread->user_id== Auth::id()): ?>
                	
                    <tr>
						<td class="activity">
                        	<div class="row">
                        	<div class="col-1">
							<img class="prof_img" src="/<?php echo e(Auth::user()->image); ?>" onerror="this.onerror=null;this.src='<?php echo e(URL::asset('images/placeholder.jpg')); ?>'">
							</div>
							<div class="col-10">
                            <strong><?php echo e($thread->subject); ?></strong>
                            <span><?php echo $thread->content; ?></span>
                            <p><?php echo e($thread->created_at->format('F j, Y g:i:s a')); ?></p>
                            </div>
							</div>
                        </td>
                    </tr>
                    
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>	
		  </div> 

		   <div class="tab-pane" id="reports" role="tabpanel">

		  	<?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  	<?php $__currentLoopData = $reports->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  	
		   		
			
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		   </div> 

		</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>