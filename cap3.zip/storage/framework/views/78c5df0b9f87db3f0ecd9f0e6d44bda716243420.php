<?php $__env->startSection('title', 'Forum'); ?>
	
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

<?php $__env->startSection('content'); ?>


<div class="row search">

		<ol class="breadcrumb mt-5">
		  <li class="breadcrumb-item"><a href="/home">Home </a></li>
		</ol>
</div>

<ul>
	<li></li>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>