<?php $__env->startSection('title', 'Thread'); ?>


<?php $__env->startSection('content'); ?>


<div class="search-container">


<ol class="breadcrumb mt-5">
  <li class="breadcrumb-item"><a href="/home">Home</a></li>
  <li class="breadcrumb-item"><a href="/forum">Forum</a></li>
</ol>
	<?php if(Auth::user()): ?>
	<a href="/forum/<?php echo e($name); ?>/<?php echo e($id); ?>/post_thread" class="btn btn-info mt-5">Post Thread</a>
	<?php else: ?>
	<div class="alert alert-primary">You Must Sign In or Register To Post A Thread</div>
	<a href="/login" class="btn btn-info mt-5">Login</a>
	<a href="/register" class="btn btn-info mt-5">Register</a>
	<?php endif; ?>
	<button class="btn btn-primary mt-5" id="show">SHOW ALL</button>
	
	
	    <?php echo e(csrf_field()); ?>

	<div class="input-group md-form form-sm form-2 pl-0 mt-5">
	    <input class="form-control search my-0 py-1 " type="text" id="search_area" placeholder="Search" data-id="<?php echo e($id); ?>" aria-label="Search">
	    <div class="input-group-append">
	        <span class="input-group-text amber lighten-3" id="search_bar"><i class="fa fa-search text-grey" aria-hidden="true"></i></span>
	    </div>
	</div>

</div>

	<div class="mt-5">
			<table class=" table-hover">
			  <thead>
			    <tr>
			      <th scope="col">Topic</th>
			      <th scope="col">Users</th>
			      <th scope="col">Replies</th>
			      <th scope="col">Latest Activity</th>
			    </tr>
			  </thead>
			  
			<?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($id == $thread->topic_id): ?>

			  <tbody id="<?php echo e($thread->id); ?>">
			    <tr class="thread" >
			      <td><a href="/threads/<?php echo e($name); ?>/<?php echo e($id); ?>/<?php echo e($thread->subject); ?>/<?php echo e($thread->id); ?>"> <?php echo e($thread->subject); ?> </a></td>

			      <td><?php echo e(count($thread->comments()->with('user')->get())); ?></td>
			      <td><?php echo e($first_thread->created_at->format('l \\of F, Y \\a\\t g:i:s a')); ?></td>
			      <td></td>
			    </tr>
			   
			  </tbody>
			<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</table>
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>