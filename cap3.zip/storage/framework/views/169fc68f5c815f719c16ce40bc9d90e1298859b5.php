<?php $__env->startSection('title', 'Post Thread'); ?>
	

<?php $__env->startSection('content'); ?>

<div class="post_margin"></div>
<ol class="breadcrumb mt-5">
	  <li class="breadcrumb-item"><a href="/home">Home</a></li>
	  <li class="breadcrumb-item"><a href="/forum">Forum</a></li>
	  <li class="breadcrumb-item"><a href="/forum/<?php echo e($name); ?>/<?php echo e($id); ?>"><?php echo e($name); ?></a></li>
</ol>


		<div class="row mt-5">
			<h2>Post Thread</h2>
		</div>

	<div class="post_container mt-2">
		
		
		<form class="mx-auto" method="post" action="/threads/<?php echo e($name); ?>/<?php echo e($id); ?>">
			<?php echo e(csrf_field()); ?>

		  <div class="form-group">
		    <input type="text" class="form-control" id="subject" name="subject" placeholder="Thread Title">
		  </div>
				
			<textarea id="thread_content" class="contents" name="thread_content">
			</textarea>

			<button type="submit" class="btn btn-primary" id="post_btn">Post Thread</button>
		</form>
		
	</div>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>