<?php $__env->startSection('title', 'Forum'); ?>
	<div class="forum_image">
        <h1>FORUMS</h1>
    </div>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

<?php $__env->startSection('content'); ?>


<div class="row">

	<div class="col-9 main-content">

<?php if(Session::has('success_message')): ?>
	<div class="alert alert-success mt-5"><?php echo e(Session::get('success_message')); ?></div>
<?php endif; ?>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<div class="card mt-5 ml-2">
		<div class="card-header"><?php echo e($category->title); ?>

			<i class="fas fa-angle-double-down float-right"></i>
		</div>
			<div class="card-body">
				<div class="row">
					
					<?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($category->id == $topic->category_id ): ?>
					
						<div class="col-md-5 mt-3">
							<img src="<?php echo e(URL::asset('images/chat.png')); ?>">
							<span class="card-title"><?php echo e($topic->name); ?></span>
						</div>
					
						<div class="col-md-2 mt-3">
							<p class="discussion">Topics</p>
							<small>1,000</small>
						</div>
					
						<div class="col-md-2 mt-3">
							<p class="discussion">Replies</p>
							<small>5,000</small>
						</div>

						<div class="col-md-3 mt-3">
							<p>Latest Activity</p>
							<div class="row">
								<div class="col-3">		
									<img class="act_image" src="<?php echo e(Auth::user()->image); ?>">
								</div>
								<div class="col-9">
									<p>thread</p>
									<p>date</p>
								</div>
							</div>
						</div>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div> 

				<hr>
				<?php if(Auth::user() && Auth::user()->role_id==1): ?> 
					<button class="btn btn-outline-danger" data-toggle="modal" data-target="#remove">Remove</button>      		
        		<?php endif; ?>

			</div> 
	</div> 


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
	</div>

	<div class="modal fade" id="remove">
	  <div class="modal-dialog">
	    <div class="modal-content">

	      <!-- Modal Header -->
	      <div class="modal-header">
	        <h4 class="modal-title">Remove Category</h4>
	        <button type="button" class="close" data-dismiss="modal">&times;</button>
	      </div>

	      <!-- Modal body -->
	      <div class="modal-body">
	        Are you sure you want to remove this from the list?
	      </div>

	      <!-- Modal footer -->
	      <div class="modal-footer">
	        <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
	      	<button class="btn btn-danger remove_list" id="<?php echo e($category->id); ?>">Remove</button>
	      </div>

	    </div>
	  </div>
	</div>

	<div class="col-3 side-content mt-5">
		
<?php if(Auth::user() && Auth::user()->role_id==1): ?> 
		<button class="btn btn-primary mb-4" data-toggle="modal" data-target="#category_modal">Add Category</button>
		<button class="btn btn-success mb-4" data-toggle="modal" data-target="#topic_modal">Add Topic</button>
<?php endif; ?>

		
		<div class="modal fade" id="category_modal">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Add Category</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		        <div class="form-group row mx-auto">
			        <form action="/forum/add" method="POST" class="col-12">
			        	<?php echo e(csrf_field()); ?>

						<label for="title" class="col-2">Title:</label>
						<input required type="text" class="col-9" id="title" name="title">
				</div>
		      </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="submit" class="btn btn-primary" id="add">Add</a>
		      </div>
			        </form>
		    </div>
		  </div>
		</div>

		
		<div class="modal fade" id="topic_modal">
		  <div class="modal-dialog">
		    <div class="modal-content">

		      <!-- Modal Header -->
		      <div class="modal-header">
		        <h4 class="modal-title">Add Topic</h4>
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		      </div>

		      <!-- Modal body -->
		      <div class="modal-body">
		      	<form action="forum/store" method="POST">
		      		<?php echo e(csrf_field()); ?>

			      	<div class="form-group row mx-auto">
						<label for="name" class="col-2">Name:</label>
						<input required type="text" class="form-control col-8" id="name" name="name">
					</div>
			      	<div class="form-group row mx-auto">
						<label for="category_id" class="col-3">Category</label>
						<select class="form-control col-8" name="category_id" id="category_id">
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
								<option value='<?php echo e($category->id); ?>'><?php echo e($category->title); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
			   </div>

		      <!-- Modal footer -->
		      <div class="modal-footer">
		        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        <button type="submit" class="btn btn-info" id="submit">Submit</button>
		      </div>
			   </form>

		    </div>
		  </div>
		</div>


		<div class="block-container online ">
		  	<h5 class="online">Online Members Now</h5>
		  	<div class="online_image">
		  		<img src="<?php echo e(Auth::user()->image); ?>">
		  	</div> 
		  	<hr>
		</div>

		<div class="block-container ">
		  	<h5 class="online">Community Stats</h5>
		  	<div class="online_image">
		  		<img src="<?php echo e(Auth::user()->image); ?>">
		  	</div>
		  	<hr>
		</div> 
	</div>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>